﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
static void main(string[] args)
{
    Console.WriteLine("Hello, World!");
}